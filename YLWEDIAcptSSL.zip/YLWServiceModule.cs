﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Web.Script.Services;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Serialization;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace YLWEDIAcptSSL
{
    public class YLWServiceModule
    {
        public static YlwSecurityJson SecurityJson { get { return securityJson; } set { securityJson = value; } }

        static string configFileName = "YLWEDIAcptSSL.Config";  //환경파일
        static Encoding baseEncoding = Encoding.GetEncoding("ks_c_5601-1987");
        static XmlDocument configXml = new XmlDocument();  //config File Xml 관리 Document

        public static string ApiDomain = "http://metrokstudio.ksystemace.com/Angkor.ylw.Common.HttpExecute/RestOutsideService.svc/GetServiceMethodSQLWFJson";
        public static string ApiDomainPost = "http://metrokstudio.ksystemace.com/Angkor.ylw.Common.HttpExecute/RestOutsideService.svc/OpenApi";
        static string encryptionType = "0";
        static string timeOut = "30";
        static string inPath = "";
        static string outPath = "";
        static string responsePath = "";
        static string sendfilePath = "";
        static string getfilePath = "";
        static string startupPath = Application.StartupPath;
        static YlwSecurityJson securityJson = new YlwSecurityJson();

        static YLWServiceModule()
        {
            //config Xml Load
            string fileName = GetPath(configFileName);

            if (!File.Exists(fileName))
            {
                //throw new Exception("Config file(" + fileName + ") does not exist");
                Debug.WriteLine("Config file(" + fileName + ") does not exist");
                return;
            }

            try
            {
                TextReader textReader = new StreamReader(fileName);
                XmlReader xmlReader = new XmlTextReader(textReader);
                configXml.Load(xmlReader);
                xmlReader.Close();
                textReader.Close();
            }
            catch (Exception xe)
            {
                //throw new Exception("Config file load error[" + xe.Message + "]");
                Debug.WriteLine("Config file(" + configFileName + ") load error[" + xe.Message + "]");
                return;
            }

            // Encoding Type Set (Default로 SET)
            baseEncoding = Encoding.GetEncoding("ks_c_5601-1987");

            XmlNodeList nodeList = configXml.SelectNodes("configuration");

            foreach (XmlNode node in nodeList)
            {
                ApiDomain = GetNodeText((XmlElement)node, "ApiDomain", ApiDomain);
                ApiDomainPost = GetNodeText((XmlElement)node, "ApiDomainPost", ApiDomainPost);
                encryptionType = GetNodeText((XmlElement)node, "encryptionType", encryptionType);
                timeOut = GetNodeText((XmlElement)node, "timeOut", timeOut);
                //string jsonStr = JsonConvert.SerializeXmlNode(node["SecurityJson"], Newtonsoft.Json.Formatting.None, true);
                securityJson.certId = GetNodeText(node["SecurityJson"], "certId");
                securityJson.certKey = GetNodeText(node["SecurityJson"], "certKey");
                securityJson.dsnOper = GetNodeText(node["SecurityJson"], "dsnOper");
                securityJson.dsn = GetNodeText(node["SecurityJson"], "dsn");
                securityJson.hostComputername = Utils.GetHostName();
                securityJson.hostIPAddress = Utils.GetMyIp();
                securityJson.userId = GetNodeText(node["SecurityJson"], "userId");
                securityJson.userPwd = GetNodeText(node["SecurityJson"], "userPwd");
                inPath = GetNodeText((XmlElement)node, "inPath", inPath);
                outPath = GetNodeText((XmlElement)node, "outPath", outPath);
                responsePath = GetNodeText((XmlElement)node, "responsePath", responsePath);
                sendfilePath = GetNodeText((XmlElement)node, "sendfilePath", sendfilePath);
                getfilePath = GetNodeText((XmlElement)node, "getfilePath", getfilePath);
                break;
            }
        }

        public static string GetInPath()
        {
            return GetPath(inPath);
        }

        public static string GetOutPath()
        {
            return GetPath(outPath);
        }

        private static string GetPath(string fileName)
        {
            return startupPath + @"\" + fileName;
        }

        private static string GetNodeText(XmlElement node, string nodeName, string defaultValue = "")
        {
            try
            {
                if (node[nodeName] != null)
                {
                    string rtnValue = node[nodeName].InnerText;
                    string enc = node[nodeName].GetAttribute("Encrypt");
                    //연결문자열이 암호화되지 않았으면 암호화 실행
                    if (enc == "Off")
                    {
                        string encstr = EncryptionUtil.EncryptString(rtnValue);
                        node[nodeName].InnerText = encstr;
                        node[nodeName].SetAttribute("Encrypt", "On");
                        SaveConfigFile();
                    }
                    else if (enc == "On") rtnValue = EncryptionUtil.DecryptString(rtnValue).Trim('\0');
                    return rtnValue;
                }
            }
            catch (Exception ex)
            {
                WriteLog(ex.Message);
            }

            return defaultValue;
        }

        private static void SaveConfigFile()
        {
            try
            {
                //Save Config File
                using (TextWriter tw = new StreamWriter(GetPath(configFileName), false, baseEncoding))
                    configXml.Save(tw);
            }
            catch (Exception ex)
            {
                WriteLog(ex.Message);
            }
        }

        public static void WriteLog(string logMsg)
        {
            try
            {
                // 폴더가 있는지 검사하고 없으면 만든다.
                string dir = startupPath + "/log/" + DateTime.Now.ToString("yyyy") + "/" + DateTime.Now.ToString("MM");
                System.IO.DirectoryInfo di = new System.IO.DirectoryInfo(dir);
                if (!di.Exists)
                {
                    di.Create();
                }
                // 파일이 있는지 검사하고 없으면 만든다.
                string file = dir + "/EDISSLTrans." + DateTime.Now.ToString("yyyyMMdd.HH") + ".log";
                if (!System.IO.File.Exists(file))
                {
                    using (System.IO.StreamWriter sw = System.IO.File.CreateText(file))
                    {
                        sw.Write("");
                        sw.Close();
                    }
                }

                // 이렇게 쓰자.
                LogWriter writer = LogWriter.Instance;
                writer.SetLogfile(file);
                writer.WriteToLog(logMsg.ToString());
            }
            catch { }
        }

        public static YlwDataSet CallYlwServiceCallPost(YlwSecurityJson security, DataSet ds)
        {
            string strReturn = string.Empty;

            string dataJson = ds.ToJsonString();

            // Parameter 추가 구문.
            var URL = new Uri(ApiDomainPost + "/" + security.serviceId + "/" + security.methodId);

            JObject postObject = new JObject();
            JObject secObj = new JObject();
            secObj.Add("certId", security.certId);
            secObj.Add("certKey", security.certKey);
            secObj.Add("dsnOper", security.dsnOper);
            secObj.Add("companySeq", security.companySeq);
            secObj.Add("data", dataJson);
            postObject.Add("ROOT", secObj);

            var postData = JObjectToJsonstring(postObject);
            var data = UTF8Encoding.UTF8.GetBytes(postData);

            try
            {
                // 서비스 콜.
                var webrequest = (HttpWebRequest)System.Net.WebRequest.Create(URL);
                webrequest.Method = "POST";
                webrequest.ContentType = "application/x-www-form-urlencoded; charset=UTF-8";
                webrequest.ContentLength = data.Length;

                // 서비스 응답 메시지 처리구문.
                using (var stream = webrequest.GetRequestStream())
                {
                    stream.Write(data, 0, data.Length);
                }

                using (var response = webrequest.GetResponse())
                {
                    using (var reader = new StreamReader(response.GetResponseStream()))
                    {
                        var result = reader.ReadToEnd();
                        strReturn = Convert.ToString(result);
                    }
                }


                try
                {
                    JToken.Parse(strReturn);  //JSON 문자열이 아니면 Catch 로
                }
                catch
                {
                    XmlDocument doc = new XmlDocument();
                    doc.LoadXml(strReturn);
                    //string deserialized = JsonConvert.SerializeXmlNode(doc, Newtonsoft.Json.Formatting.None, true);
                    //JObject yob = JsonConvert.DeserializeObject<JObject>(deserialized);
                    XmlNodeList nodeList = doc.GetElementsByTagName("ErrorMessage");
                    if (nodeList != null && nodeList.Count > 0)
                    {
                        //MessageBox.Show(nodeList[0].InnerText);
                        WriteLog(nodeList[0].InnerText);
                        return null;
                    }
                    WriteLog("JToken.Parse Error");
                    return null;
                }
                string deserialized = JsonConvert.DeserializeObject<string>(strReturn);
                JsonSerializerSettings settings = new JsonSerializerSettings() { StringEscapeHandling = StringEscapeHandling.EscapeHtml };
                YlwDataSet yds = JsonConvert.DeserializeObject<YlwDataSet>(deserialized, settings);
                if (yds.Tables[0].TableName == "ErrorMessage")
                {
                    MessageBox.Show(yds.Tables[0].Rows[0]["Result"].ToString());
                    return null;
                }
                return yds;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        //GET 방식
        public static YlwDataSet CallYlwServiceCall(YlwSecurityJson security, DataSet ds)
        {
            string strReturn = string.Empty;

            string securityJson = Utils.ClassToJsonstring(security);
            securityJson = securityJson.Replace("\"", "");   //securityJson 에 " 가 있으면 영림원에러 발생됨.
            string dataJson = ds.ToJsonString();

            // Parameter 추가 구문.
            var URL = new Uri(ApiDomain);
            URL = URL.AddQuery("securityJson", securityJson);
            URL = URL.AddQuery("dataJson", dataJson);
            URL = URL.AddQuery("encryptionType", encryptionType);
            URL = URL.AddQuery("timeOut", timeOut);

            try
            {
                // 서비스 콜.
                var webrequest = (HttpWebRequest)System.Net.WebRequest.Create(URL);

                // 서비스 응답 메시지 처리구문.
                using (var response = webrequest.GetResponse())
                {
                    using (var reader = new StreamReader(response.GetResponseStream()))
                    {
                        var result = reader.ReadToEnd();
                        strReturn = Convert.ToString(result);
                    }
                }

                try
                {
                    JToken.Parse(strReturn);  //JSON 문자열이 아니면 Catch 로
                }
                catch
                {
                    XmlDocument doc = new XmlDocument();
                    doc.LoadXml(strReturn);
                    //string deserialized = JsonConvert.SerializeXmlNode(doc, Newtonsoft.Json.Formatting.None, true);
                    //JObject yob = JsonConvert.DeserializeObject<JObject>(deserialized);
                    XmlNodeList nodeList = doc.GetElementsByTagName("ErrorMessage");
                    if (nodeList != null && nodeList.Count > 0)
                    {
                        //MessageBox.Show(nodeList[0].InnerText);
                        WriteLog(nodeList[0].InnerText);
                        return null;
                    }
                    WriteLog("JToken.Parse Error");
                    return null;
                }
                string deserialized = JsonConvert.DeserializeObject<string>(strReturn);
                JsonSerializerSettings settings = new JsonSerializerSettings() { StringEscapeHandling = StringEscapeHandling.EscapeHtml };
                YlwDataSet yds = JsonConvert.DeserializeObject<YlwDataSet>(deserialized, settings);
                if (yds.Tables[0].TableName == "ErrorMessage")
                {
                    MessageBox.Show(yds.Tables[0].Rows[0]["Result"].ToString());
                    return null;
                }
                return yds;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public static DataTable GetYlwServiceDataTable(string strSql)
        {
            try
            {
                YlwSecurityJson security = YLWServiceModule.SecurityJson.Clone();  //깊은복사
                security.serviceId = "Metro.Package.AdjSL.BisAdjSLReturnJSON";
                security.methodId = "Query";

                DataSet ds = new DataSet("ROOT");
                DataTable dt = ds.Tables.Add("DataBlock1");

                dt.Columns.Add("SQL");
                DataRow dr = dt.Rows.Add();
                dr["SQL"] = strSql;

                YlwDataSet yds = CallYlwServiceCall(security, ds);
                if (yds.Tables.Count < 1) return null;
                YlwTable datablock1 = yds.GetDataBlock("DataBlock1");
                if (datablock1 == null) return null;
                return JsonConvert.DeserializeObject<DataTable>(datablock1.Rows[0]["JSON"].ToString());
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public static string JObjectToJsonstring(object jobj)
        {
            return JsonConvert.SerializeObject(jobj);
        }
    }

    public static class HttpExtensions
    {
        public static Uri AddQuery(this Uri uri, string name, string value)
        {
            //var httpValueCollection = HttpUtility.ParseQueryString(uri.Query);

            //httpValueCollection.Remove(name);
            //httpValueCollection.Add(name, value);

            //var ub = new UriBuilder(uri);
            //ub.Query = httpValueCollection.ToString();

            //return ub.Uri;

            //한글 문제 있음

            string newUrl = uri.OriginalString;

            if (newUrl.EndsWith("&") || newUrl.EndsWith("?"))
                newUrl = string.Format("{0}{1}={2}", newUrl, name, value);
            else if (newUrl.Contains("?"))
                newUrl = string.Format("{0}&{1}={2}", newUrl, name, value);
            else
                newUrl = string.Format("{0}?{1}={2}", newUrl, name, value);

            return new Uri(newUrl);
        }
    }

    public class YlwSecurityJson : ICloneable
    {
        public string certId { get; set; }
        public string certKey { get; set; }
        public string dsnOper { get; set; }
        public string dsn { get; set; }
        public string workingTag { get; set; } = "";
        public int securityType { get; set; } = 0;
        public int isDebug { get; set; } = 0;
        public int companySeq { get; set; } = 1;
        public int languageSeq { get; set; } = 1;
        public string serviceId { get; set; }
        public string methodId { get; set; }
        public string hostComputername { get; set; }
        public string hostIPAddress { get; set; }
        public string userId { get; set; }
        public string userPwd { get; set; }
        public int empSeq { get; set; }

        #region ICloneable Members
        // Type safe Clone
        public YlwSecurityJson Clone()
        {
            return new YlwSecurityJson()
            {
                certId = this.certId,
                certKey = this.certKey,
                dsnOper = this.dsnOper,
                dsn = this.dsn,
                workingTag = this.workingTag,
                securityType = this.securityType,
                isDebug = this.isDebug,
                companySeq = this.companySeq,
                languageSeq = this.languageSeq,
                serviceId = this.serviceId,
                methodId = this.methodId,
                hostComputername = this.hostComputername,
                hostIPAddress = this.hostIPAddress,
                userId = this.userId,
                userPwd = this.userPwd,
                empSeq = this.empSeq
            };
        }

        // ICloneable implementation
        object ICloneable.Clone()
        {
            return Clone();
        }
        #endregion
    }

    public class YlwDataSet
    {
        public List<YlwTable> Tables;

        public YlwTable GetDataBlock(string blockName)
        {
            return this.Tables.Find(x => x.TableName == blockName);
        }
    }

    public class YlwTable
    {
        public string TableName { get; set; }
        public List<YlwColumn> Columns { get; set; }
        public List<JObject> Rows { get; set; }
    }

    public class YlwColumn
    {
        public string ColumnName { get; set; }
        public string ColumnType { get; set; }
    }
}
