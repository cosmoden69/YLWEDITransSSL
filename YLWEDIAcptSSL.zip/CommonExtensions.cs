﻿using System.Collections.Generic;
using System.Data;
using System.Web.Script;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

public static class CommonExtensions
{
    public static JObject ToJson(this DataTable dt)
    {
        System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
        serializer.MaxJsonLength = 2147483647;

        List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
        Dictionary<string, object> row;

        for (int ii = 0; ii < dt.Rows.Count; ii++)
        {
            DataRow dr = dt.Rows[ii];
            row = new Dictionary<string, object>();
            foreach (DataColumn col in dt.Columns)
            {
                row.Add(col.ColumnName, dr[col]);
            }
            rows.Add(row);
        }

        JObject dataTable = new JObject();
        try
        {
            JArray jobj = JArray.Parse(serializer.Serialize(rows));
            dataTable.Add(dt.TableName, jobj);
        }
        catch { }

        return dataTable;
    }

    public static string ToJsonString(this DataTable dt)
    {
        return JsonConvert.SerializeObject(dt.ToJson());
    }

    public static JObject ToJson(this DataSet ds)
    {
        System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
        serializer.MaxJsonLength = 2147483647;

        Dictionary<string, List<Dictionary<string, object>>> dtList = new Dictionary<string, List<Dictionary<string, object>>>();
        List<Dictionary<string, object>> rows;
        Dictionary<string, object> row;

        foreach (DataTable dt in ds.Tables)
        {
            rows = new List<Dictionary<string, object>>();
            for (int ii = 0; ii < dt.Rows.Count; ii++)
            {
                DataRow dr = dt.Rows[ii];
                row = new Dictionary<string, object>();
                foreach (DataColumn col in dt.Columns)
                {
                    row.Add(col.ColumnName, dr[col]);
                }
                rows.Add(row);
            }
            dtList.Add(dt.TableName, rows);
        }

        JObject dataSet = new JObject();
        try
        {
            string str = serializer.Serialize(dtList);
            JObject jobj = JObject.Parse(str);
            dataSet.Add(ds.DataSetName, jobj);
        }
        catch { }

        return dataSet;
    }

    public static string ToJsonString(this DataSet ds)
    {
        return JsonConvert.SerializeObject(ds.ToJson());
    }

    public static void AddColumn(this DataGridView grv, string type, string name, string title, int width, bool visible = true)
    {
        DataGridViewColumn dgvf;
        if (type.ToUpper() == "TEXTBOX")
        {
            dgvf = new DataGridViewTextBoxColumn();
            dgvf.DataPropertyName = name;
        }
        else
        {
            dgvf = new DataGridViewTextBoxColumn();
            dgvf.DataPropertyName = name;
        }
        dgvf.HeaderText = title;
        dgvf.Name = name;
        dgvf.Width = width;
        dgvf.Visible = visible;
        grv.Columns.Add(dgvf);
    }
}
