using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace YLWEDIAcptSSL
{
    public partial class frmAcptUploadSSL : Form
    {
        bool _bEvent = false;

        string selectedPath = "";

        public frmAcptUploadSSL()
        {
            InitializeComponent();

            this.Load += FrmAcptUploadSSL_Load;

            SetInit();

            _bEvent = true;
        }

        private void FrmAcptUploadSSL_Load(object sender, EventArgs e)
        {
            tsbReadDirectory.PerformClick();
        }

        private void SetInit()
        {
            selectedPath = YLWServiceModule.GetInPath();

            SetComboDept(cboDept);
        }

        private void tsbReadDirectory_Click(object sender, EventArgs e)
        {
            try
            { 
                DataTable table = new DataTable();

                // column�� �߰��մϴ�.
                table.Columns.Add("filename", typeof(string));
                table.Columns.Add("filesize", typeof(Int32));
                table.Columns.Add("changedate", typeof(string));
                table.Columns.Add("filepath", typeof(string));

                DirectoryInfo root = new DirectoryInfo(selectedPath);
                var files = root.GetFiles("*.*", SearchOption.TopDirectoryOnly);
                foreach (var file in files)
                {
                    //if (file.Name == "HubornCRM.AutoUpdater.dll") continue;
                    table.Rows.Add(file.FullName.Replace(selectedPath + "\\", string.Empty), file.Length, file.LastWriteTime, file.FullName);
                }

                // ������ �Էµ� ���̺��� DataGridView�� �Է��մϴ�.
                dgvList.DataSource = table;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void tsbRowDelete_Click(object sender, EventArgs e)
        {
            try
            {
                foreach (DataGridViewRow row in dgvList.SelectedRows)
                {
                    dgvList.Rows.Remove(row);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void tsbUpload_Click(object sender, EventArgs e)
        {
            string dept = Utils.GetComboSelectedValue(cboDept, "BeDeptSeq");
            if (dept == "")
            {
                MessageBox.Show("�������� �ʼ��Դϴ�");
                return;
            }

            try
            {
                var files = Directory.GetFiles(selectedPath, "*.txt", SearchOption.TopDirectoryOnly);
                if (files.Length < 1) return;
                if (!ReadTxtFile(files[0]))  //��������
                {
                    return;
                }
                tsbReadDirectory.PerformClick();
                MessageBox.Show("���� ���ε� �Ϸ�");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public bool ReadTxtFile(string txtFile)
        {
            YlwSecurityJson security = YLWServiceModule.SecurityJson.Clone();  //��������
            security.serviceId = "Metro.Package.AdjSL.BisAdjSLEDITransSSL";
            security.methodId = "in";

            DataSet ds = new DataSet("ROOT");
            DataTable dt = ds.Tables.Add("DataBlock1");

            dt.Columns.Add("WorkingTag");
            dt.Columns.Add("IDX_NO");
            dt.Columns.Add("DataSeq");
            dt.Columns.Add("Status");
            dt.Columns.Add("Selected");
            dt.Columns.Add("TABLE_NAME");

            dt.Columns.Add("companyseq");
            dt.Columns.Add("send_type");
            dt.Columns.Add("success_fg");
            dt.Columns.Add("cust_code");
            dt.Columns.Add("trans_dtm");
            dt.Columns.Add("file_name");
            dt.Columns.Add("edi_text");
            dt.Columns.Add("CclsFg");
            dt.Columns.Add("AsgnTeamSeq");
            dt.Columns.Add("AsgnEmpSeq");
            dt.Columns.Add("remain");

            try
            {
                string filename = Path.GetFileName(txtFile);
                string editext = "";
                using (StreamReader str = new StreamReader(txtFile, Encoding.Default))
                {
                    editext = str.ReadToEnd();
                }
                string dept = Utils.GetComboSelectedValue(cboDept, "BeDeptSeq");
                string emp = txtEmpSeq.Text;
                string cclsfg = "0";
                if (dept != "") cclsfg = "1";
                if (emp != "") cclsfg = "2";


                dt.Clear();
                DataRow dr = dt.Rows.Add();

                dr["WorkingTag"] = "A";
                dr["IDX_NO"] = 1;
                dr["DataSeq"] = 1;
                dr["Status"] = 0;
                dr["Selected"] = 0;
                dr["TABLE_NAME"] = dt.TableName;

                dr["companyseq"] = security.companySeq;
                dr["send_type"] = 0;
                dr["success_fg"] = 0;
                dr["cust_code"] = "SSL";
                dr["file_name"] = filename;
                dr["edi_text"] = editext;
                dr["CclsFg"] = cclsfg;
                dr["AsgnTeamSeq"] = dept;
                dr["AsgnEmpSeq"] = emp;

                //�幮�� ���ؼ� POST �����ؾ� ��
                YlwDataSet yds = YLWServiceModule.CallYlwServiceCall(security, ds);
                if (yds != null && yds.Tables.Count > 0)
                {
                    YlwTable dataBlock1 = yds.GetDataBlock("DataBlock1");
                    if (dataBlock1 != null)
                    {
                        if (dataBlock1.Rows[0]["success_fg"] + "" == "1")
                        {
                            File.Delete(txtFile);

                            string edi_id = dataBlock1.Rows[0]["edi_id"] + "";

                            var files = Directory.GetFiles(selectedPath, "*.*", SearchOption.TopDirectoryOnly);
                            foreach (var file in files)  //÷������
                            {
                                if (Path.GetExtension(file).ToUpper() == ".TXT") continue;
                                ReadAttachFile(edi_id, file);
                            }
                        }
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                YLWServiceModule.WriteLog(ex.Message);
                return false;
            }
        }

        public bool ReadAttachFile(string edi_id, string file)
        {
            YlwSecurityJson security = YLWServiceModule.SecurityJson.Clone();  //��������
            security.serviceId = "Metro.Package.AdjSL.BisAdjSLEDITransSSL";
            security.methodId = "attach";

            DataSet ds = new DataSet("ROOT");
            DataTable dt = ds.Tables.Add("DataBlock1");

            dt.Columns.Add("WorkingTag");
            dt.Columns.Add("IDX_NO");
            dt.Columns.Add("DataSeq");
            dt.Columns.Add("Status");
            dt.Columns.Add("Selected");
            dt.Columns.Add("TABLE_NAME");

            dt.Columns.Add("companyseq");
            dt.Columns.Add("edi_id");
            dt.Columns.Add("file_name");
            dt.Columns.Add("file_length");
            dt.Columns.Add("file_base64");

            try
            {
                string filename = Path.GetFileName(file);
                Byte[] bytes = File.ReadAllBytes(file);
                string file_base64 = Convert.ToBase64String(bytes);

                dt.Clear();
                DataRow dr = dt.Rows.Add();

                dr["WorkingTag"] = "A";
                dr["IDX_NO"] = 1;
                dr["DataSeq"] = 1;
                dr["Status"] = 0;
                dr["Selected"] = 0;
                dr["TABLE_NAME"] = dt.TableName;

                dr["companyseq"] = security.companySeq;
                dr["edi_id"] = edi_id;
                dr["file_name"] = filename;
                dr["file_base64"] = "";  //file_base64;

                //�幮�� ���ؼ� POST �����ؾ� ��
                YlwDataSet yds = YLWServiceModule.CallYlwServiceCall(security, ds);
                if (yds != null && yds.Tables.Count > 0)
                {
                    YlwTable dataBlock1 = yds.GetDataBlock("DataBlock1");
                    if (dataBlock1 != null)
                    {
                        if (dataBlock1.Rows[0]["success_fg"] + "" == "1")
                        {
                            File.Delete(file);
                        }
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                YLWServiceModule.WriteLog(ex.Message);
                return false;
            }
        }

        private void tsbClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ClearScreen()
        {
            _bEvent = false;

            cboDept.SelectedIndex = -1;
            txtEmp.Text = "";
            txtEmpSeq.Text = "";
            DataTable dtr = (DataTable)dgvList.DataSource;
            if (dtr != null) dtr.Rows.Clear();

            _bEvent = true;
        }

        private void ClearFolder()
        {
            try
            {
                DirectoryInfo dir = new DirectoryInfo(selectedPath);
                var files = dir.GetFiles("*.*", SearchOption.TopDirectoryOnly);
                foreach (var file in files)
                {
                    file.Attributes = FileAttributes.Normal;
                    file.Delete();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void SetComboDept(ComboBox cboObj)
        {
            string strSql = "";
            strSql += @" SELECT A.DeptName AS BeDeptName ";
            strSql += @"     ,A.BegDate AS BeBegDate ";
            strSql += @"     ,A.EndDate AS BeEndDate ";
            strSql += @"     ,A.Remark AS DeptRemark ";
            strSql += @"     ,A.DeptSeq AS BeDeptSeq ";
            strSql += @"     ,CASE WHEN A.EndDate >= CONVERT(NCHAR(8), GETDATE(), 112) THEN '1' ELSE '0' END AS IsUse  ";  /* �������� �������� ������� �μ����� �ƴ��� �Ǵ� */
            strSql += @" FROM _TDADept AS A WITH(NOLOCK) ";
            strSql += @"      LEFT JOIN _THROrgDeptCCtr AS B WITH(NOLOCK) ON A.CompanySeq = B.CompanySeq AND A.DeptSeq = B.DeptSeq AND B.IsLast = '1' ";   /* ������ ���� Ȱ�����͸� ǥ���Ѵ�. 2011.12.08 ������ */
            strSql += @"      LEFT JOIN _TDACCtr AS C WITH(NOLOCK) ON A.CompanySeq = C.CompanySeq AND B.CCtrSeq = C.CCtrSeq ";
            strSql += @" WHERE A.CompanySeq = @CompanySeq ";
            strSql += @" AND   A.SMDeptType NOT IN(3051003, 3051004) ";  /* TFT����, BPM�μ� ���� */
            strSql += @" ";  /* AND CASE @DefQueryOption WHEN 0 THEN CONVERT(NVARCHAR(10), A.DeptSeq) ELSE A.DeptName END LIKE @Keyword */
            strSql += @" ORDER BY A.DeptName, A.DispSeq ";
            strSql += @" FOR JSON PATH ";

            List<IDbDataParameter> lstPara = new List<IDbDataParameter>();
            lstPara.Clear();
            lstPara.Add(new SqlParameter("@CompanySeq", YLWServiceModule.SecurityJson.companySeq));
            strSql = Utils.GetSQL(strSql, lstPara.ToArray());

            Utils.SetCombo(cboObj, strSql, "BeDeptSeq", "BeDeptName", true);
        }

        private void txtEmp_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            string dept = Utils.GetComboSelectedValue(cboDept, "BeDeptSeq");
            FrmFindEmp f = new FrmFindEmp(dept, txtEmp.Text);
            if (f.ShowDialog(this) == DialogResult.OK)
            {
                _bEvent = false;
                txtEmp.Text = f.ReturnFields.Find(x => x.FieldCode == "EmpName").FieldValue.ToString();
                txtEmpSeq.Text = f.ReturnFields.Find(x => x.FieldCode == "EmpSeq").FieldValue.ToString();
                dept = f.ReturnFields.Find(x => x.FieldCode == "DeptSeq").FieldValue.ToString();
                Utils.SetComboSelectedValue(cboDept, dept, "BeDeptSeq");
                _bEvent = true;
            }
        }

        private void cboDept_SelectedValueChanged(object sender, EventArgs e)
        {
            if (!_bEvent) return;
            txtEmp.Text = "";
            txtEmpSeq.Text = "";
        }
    }
}