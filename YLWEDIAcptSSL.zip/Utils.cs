﻿using System;
using System.Collections;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.ComponentModel;
using System.Drawing;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Reflection;
using System.Xml;
using System.Xml.Serialization;
using System.Xml.Xsl;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Web.Script.Services;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace YLWEDIAcptSSL
{
    public class Utils
    {
        private static int StrContains(string source, string target, int startIndex)
        {
            int count = 0, pos;
            int index = startIndex;
            while ((pos = source.IndexOf(target, index)) >= 0)
            {
                index = pos + target.Length;
                count++;
            }
            return count;
        }

        [Description("문자가 Delimiter인지 여부를 Return합니다.")]
        private static bool IsDelimiter(char ch)
        {
            return !((char.IsLetterOrDigit(ch)) || (ch == '_'));
        }

        [Description("Split 을 char가 아닌 string으로 구분합니다.")]
        public static string[] SplitByString(string testString, string split)
        {
            int offset = 0;
            int index = 0;
            int[] offsets = new int[testString.Length + 1];
            while (index < testString.Length)
            {
                int indexOf = testString.IndexOf(split, index);
                if (indexOf != -1)
                {
                    offsets[offset++] = indexOf;
                    index = (indexOf + split.Length);
                }
                else
                {
                    index = testString.Length;
                }
            }
            string[] final = new string[offset + 1];
            if (offset == 0)
            {
                final[0] = testString;
            }
            else
            {
                offset--;
                final[0] = testString.Substring(0, offsets[0]);
                for (int i = 0; i < offset; i++)
                {
                    final[i + 1] = testString.Substring(offsets[i] + split.Length, offsets[i + 1] - offsets[i] - split.Length);
                }
                final[offset + 1] = testString.Substring(offsets[offset] + split.Length);
            }
            return final;
        }

        public static string Join(int depth, params string[] param)
        {
            return Join(Convert.ToString((char)(20 + depth)), param);
        }

        public static string Join(string deli, params string[] param)
        {
            string rtn = string.Empty;

            for (int i = 0; i < param.Length; i++)
            {
                if (i > 0) rtn += deli;
                rtn += param[i];
            }
            return rtn;
        }

        public static int GetPos(string src, int depth, string dest)
        {
            return GetPos(src, Convert.ToString((char)(20 + depth)), dest);
        }

        public static int GetPos(string src, string deli, string dest)
        {
            try
            {
                int maxp = GetPlen(src, deli);
                if (maxp < 1) return 0;
                for (int ii = 1; ii <= maxp; ii++)
                {
                    string piece = GetP(src, deli, ii);
                    if (piece == dest) return ii;
                }
                return 0;
            }
            catch { }

            return 0;
        }

        public static int GetPlen(string source, int depth)
        {
            return GetPlen(source, Convert.ToString((char)(20 + depth)));
        }

        public static int GetPlen(string source, string deli)
        {
            return StrContains(source, deli, 0) + 1;
        }

        public static string SetP(string source, string deli, int pos, string trans)
        {
            string rtn = "";

            if (deli == "" || pos < 1) return "";

            int iMaxLen = GetPlen(source, deli);
            int iDeliCnt = (pos > iMaxLen ? pos - iMaxLen : 0);
            string tmpDelis = "";
            for (int i = 1; i <= iDeliCnt; i++) tmpDelis += deli;
            string tmpDeli1 = "";
            if (pos <= iMaxLen && pos > 1) tmpDeli1 = deli;
            string tmpDeli2 = "";
            if (pos < iMaxLen && pos >= 1) tmpDeli2 = deli;
            int iLastPos = (pos > iMaxLen ? pos : iMaxLen);
            rtn = GetPs(source, deli, 1, pos - 1);
            rtn += tmpDelis;
            rtn += tmpDeli1;
            rtn += trans;
            rtn += tmpDeli2;
            rtn += GetPs(source, deli, pos + 1, iLastPos);
            return rtn;
        }

        public static string GetPs(string para, string deli, int frP, int toP)
        {
            string rtn = "";

            if (deli == "") return "";
            if (frP < 1) frP = 1;
            int len = GetPlen(para, deli);
            if (toP > len) toP = len;
            if (frP > toP) return "";

            try
            {
                int cnt = 0;
                string[] tmp = SplitByString(para, deli);
                for (int ii = frP; ii <= toP; ii++)
                {
                    if (cnt > 0) rtn = rtn + deli;
                    rtn = rtn + (tmp.Length >= ii ? tmp[ii - 1] : "");
                    cnt++;
                }
            }
            catch { }

            return rtn;
        }

        [Description("문자열을 구분자로 해당위치에서 하나만 잘라 옵니다.")]
        public static string GetP(string para, int depth, int pos)
        {
            return GetP(para, Convert.ToString((char)(20 + depth)), pos);
        }

        [Description("문자열을 구분자로 해당위치에서 하나만 잘라 옵니다.")]
        public static string GetP(string para, string deli, int pos)
        {
            string rtn = "";

            try
            {
                rtn = SplitByString(para, deli)[pos - 1];
            }
            catch { }

            return rtn;
        }

        [Description("문자열을 구분자로 순서대로 하나씩 잘라 옵니다.")]
        public static string Shift(ref string para, int depth)
        {
            return Shift(ref para, Convert.ToString((char)(20 + depth)));
        }

        [Description("문자열을 구분자로 순서대로 하나씩 잘라 옵니다.")]
        public static string Shift(ref string para, string deli)
        {
            string rtn = "";

            int indexOf = para.IndexOf(deli);
            if (indexOf != -1)
            {
                rtn = para.Substring(0, indexOf);
                para = para.Substring(indexOf + deli.Length);
            }
            else
            {
                rtn = para;
                para = "";
            }

            return rtn;
        }

        [Description("문자열을 정해진 위치에서 잘라 옵니다.(From ~ To, start는 1 부터)")]
        public static string Mid(string para, int from, int to)
        {
            if (from < 1) from = 1;
            if (to > para.Length) to = para.Length;
            if (from > to) return "";
            if (from > para.Length) return "";
            return para.Substring(from - 1, to - from + 1);
        }

        [Description("문자열을 정해진 위치에서 잘라 옵니다.(start는 0 부터)")]
        public static string SubString(string para, int start, int length)
        {
            if (start > para.Length - 1) return "";
            return para.Substring(start, System.Math.Min(length, para.Length - start));
        }

        [Description("내IP 가져오기")]
        public static string GetMyIp()
        {
            IPHostEntry host = Dns.GetHostEntry(Dns.GetHostName());
            string ip = "";
            for (int i = 0; i < host.AddressList.Length; i++)
            {
                if (host.AddressList[i].AddressFamily == AddressFamily.InterNetwork)
                {
                    ip = host.AddressList[i].ToString();
                    break;
                }
            }
            return ip;
        }

        [Description("내공인IP 가져오기")]
        public static string GetExternalIPAddress()
        {
            string externalip = new WebClient().DownloadString("http://ipinfo.io/ip").Trim();  //http://icanhazip.com

            if (String.IsNullOrWhiteSpace(externalip))
            {
                externalip = GetMyIp();  //null경우 Get Internal IP를 가져오게 한다.
            }

            return externalip;
        }

        [Description("내컴퓨터이름 가져오기")]
        public static string GetHostName()
        {
            IPHostEntry host = Dns.GetHostEntry(Dns.GetHostName());
            return host.HostName;
        }

        public static Image stringToImage(string inputString)
        {
            try
            {
                byte[] imageBytes = Convert.FromBase64String(inputString);
                MemoryStream ms = new MemoryStream(imageBytes);

                Image image = Image.FromStream(ms, true, true);

                return image;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return null;
            }
        }

        public static string ClassToJsonstring(object cls)
        {
            return new JavaScriptSerializer().Serialize(cls);
        }

        public static string JObjectToJsonstring(object jobj)
        {
            return JsonConvert.SerializeObject(jobj);
        }

        public static string GetSQL(string sqlText, IDbDataParameter[] parameters)
        {
            int pos = -1;
            int startIndex = 0;
            int index = startIndex;
            int cmtPos;
            bool loopExit = false;
            string symbol = "@";

            //  Bind 변수의 판단을 BindSymbol로 통일 (Oracle -> :, SqlServer -> @, DB2 -> @)
            while (((pos = sqlText.IndexOf(symbol, index)) >= 0) && !loopExit)
            {
                index = pos + 1;
                // 앞의 Character가 separator인지 여부 확인
                if (pos > 0)
                    if (!IsDelimiter(sqlText[pos - 1])) continue;
                // Comment인지 여부 확인
                string chkStmt = sqlText.Substring(startIndex, pos - startIndex);
                if ((cmtPos = chkStmt.LastIndexOf("/*")) >= 0)
                    if (chkStmt.IndexOf("*/", cmtPos + 2) < 0) continue;
                if ((cmtPos = chkStmt.LastIndexOf("--")) >= 0)
                    if (chkStmt.IndexOf("\n", cmtPos + 2) < 0) continue;
                if ((StrContains(chkStmt, "\'", 0) % 2) >= 1) continue;
                loopExit = true;
                for (int i = pos + 1; i <= sqlText.Length; i++)
                {
                    if (i == sqlText.Length)
                    {
                        string varName = sqlText.Substring(pos);
                        IDbDataParameter p;
                        try
                        {
                            p = parameters.First(x => x.ParameterName == varName);
                        }
                        catch
                        {
                            loopExit = true;
                            break;
                        }
                        string replace = "'" + p.Value + "'";
                        sqlText = sqlText.Remove(pos);
                        sqlText = sqlText.Insert(pos, replace);
                        loopExit = true;
                        break;
                    }
                    else if (IsDelimiter(sqlText[i]))
                    {
                        string varName = sqlText.Substring(pos, i - pos);
                        IDbDataParameter p;
                        try
                        {
                            p = parameters.First(x => x.ParameterName == varName);
                        }
                        catch
                        {
                            loopExit = false;
                            break;
                        }
                        string replace = "'" + p.Value + "'";
                        sqlText = sqlText.Remove(pos, i - pos);
                        sqlText = sqlText.Insert(pos, replace);
                        startIndex = pos + replace.Length;
                        index = startIndex;
                        loopExit = false;
                        break;
                    }
                }
            }
            //if p.DbType == DbType.Int16

            return sqlText;
        }

        public static void SetCombo(ComboBox cboObj, string strSql, string strValueMember, string strDisplayMember, bool bAddnull)
        {
            try
            {
                if (cboObj.DataSource != null) cboObj.DataSource = null;
                cboObj.Items.Clear();

                DataTable dt = YLWServiceModule.GetYlwServiceDataTable(strSql);
                if (dt == null || dt.Rows.Count < 1)
                {
                    return;
                }
                if (bAddnull)
                {
                    DataRow drTmp = dt.NewRow();
                    drTmp[strValueMember] = DBNull.Value;
                    drTmp[strDisplayMember] = "";
                    dt.Rows.InsertAt(drTmp, 0);
                }
                cboObj.DataSource = dt;
                cboObj.ValueMember = strValueMember;
                cboObj.DisplayMember = strDisplayMember;
                cboObj.SelectedIndex = -1;
            }
            catch (Exception er)
            {
                MessageBox.Show(er.ToString());
            }
        }

        public static string GetComboSelectedValue(ComboBox comboBox, string codeMember)
        {
            try
            {
                int index = comboBox.SelectedIndex;
                if (index == -1) return "";
                string strRet = ((DataTable)comboBox.DataSource).Rows[index][codeMember].ToString();
                return strRet;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public static void SetComboSelectedValue(ComboBox comboBox, string value, string codeMember)
        {
            try
            {
                Boolean bFind = false;
                for (int i = 0; i < comboBox.Items.Count; i++)
                {
                    string strCode = ((DataTable)comboBox.DataSource).Rows[i][codeMember].ToString();
                    if (strCode == value)
                    {
                        comboBox.SelectedIndex = i;
                        bFind = true;
                        break;
                    }
                }
                if (bFind == false)
                {
                    comboBox.SelectedIndex = -1;
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}
